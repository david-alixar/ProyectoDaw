package com.dawProject.dawProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
