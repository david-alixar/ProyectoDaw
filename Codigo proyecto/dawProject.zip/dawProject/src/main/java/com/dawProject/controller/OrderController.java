package com.dawProject.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dawProject.form.AltaProductoForm;
import com.dawProject.model.*;
import com.dawProject.service.*;



@Controller
public class OrderController {

	@Autowired
	private ProductService productService;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private OrderDetailService orderDetailService;
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping("/cart")
	public String cart(Model model, HttpServletRequest request) {
		HttpSession mysession = request.getSession(true);
		User user = obtenerUsuarioSesion(request);
		if (user == null) {
			return "redirect:/login";
		}
		Customer customer = customerService.findByusername(user.getUsername());
		Order order = orderService.findByCustomerPending(customer.getUsername());
		if (order == null) {
			model.addAttribute("orderDetails", null);
		}
		else {
			model.addAttribute("orderDetails", orderDetailService.findCart(order.getOrderNumber()));
		}
		return "/user/cart";	
	}
	
	@GetMapping("/buyProduct/{productCode}")
	public String buyProduct(
			Model model,
			@PathVariable("productCode") int productCode, HttpServletRequest request) {
		User user = obtenerUsuarioSesion(request);
		if (user == null) {
			return "redirect:/login";
		}
		Customer customer = customerService.findByusername(user.getUsername());
		
		Order order = orderService.findByCustomerPending(customer.getUsername());
		
		if (order == null) {
			order = new Order(LocalDate.now().toString(),"No finalizado", "Vacío", 0, customer);
			orderService.save(order);
		}
		
		Product product = productService.findByProductCode(productCode);
		OrderDetail orderDetail = orderDetailService.findByOrderDetailIdProduct(productCode, order.getOrderNumber());

		if(orderDetail == null) {
			orderDetail = new OrderDetail(1, product.getPrice(), product, order);
		} else {
			orderDetail.setQuantity(orderDetail.getQuantity() + 1);
		}
		orderDetailService.save(orderDetail);
		model.addAttribute("orderDetails", orderDetailService.findAll());
		return "/user/cart";
		
	}
	
	@GetMapping("/dropCart")
	public String dropCart(
		Model model, HttpServletRequest request) {
		User user = obtenerUsuarioSesion(request);
		if (user == null) {
			return "redirect:/login";
		}
		Customer customer = customerService.findByusername(user.getUsername());
		Order order = orderService.findByCustomerPending(customer.getUsername());
		List <OrderDetail> list = orderDetailService.findCart(order.getOrderNumber());
		
		for (OrderDetail o : list) {
			orderDetailService.delete(o);
		}
		
		orderService.delete(order);
		return "/productsList";
	}
	
	
	private User obtenerUsuarioSesion(HttpServletRequest request) {
		HttpSession session = request.getSession();
		return (User) session.getAttribute("user");
	}

}
